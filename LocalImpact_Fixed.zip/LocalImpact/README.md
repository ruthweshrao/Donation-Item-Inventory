# LocalImpact — Fixed runnable project

## Requirements
- Python 3.10 or newer
- Windows PowerShell / Command Prompt

## Run on Windows
Open this folder in VS Code, then in the terminal run:

```powershell
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
py -m uvicorn app:app --reload
```

Open **http://127.0.0.1:8000** in your browser.
API documentation: **http://127.0.0.1:8000/docs**

Alternative launcher:
```powershell
py main.py --web
```

## Features
- Search and filter community resources
- Add, update and delete resources
- Capacity and status tracking
- Dashboard summary and critical capacity alerts
- Data validation and JSON persistence
- CSV and Markdown exports

The data is stored in `data/directory.json`. Backups are written when data is saved.
