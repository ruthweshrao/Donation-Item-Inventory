from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field
from src.storage import DirectoryStorage
from src.engine import DirectoryEngine
from src.models import Resource, VALID_CATEGORIES, VALID_STATUSES
from src.auditor import DirectoryAuditor
from src.exporters import DirectoryExporter

ROOT = Path(__file__).resolve().parent
storage = DirectoryStorage(ROOT / "data" / "directory.json")
engine = DirectoryEngine(storage)
auditor = DirectoryAuditor()
exporter = DirectoryExporter(ROOT / "exports")

app = FastAPI(title="Local Resource Directory API", description="Safety & Community Services Directory", version="1.1.0")

class ResourceCreate(BaseModel):
    name: str = Field(..., min_length=1)
    category: str
    address: str = Field(..., min_length=1)
    contact: str = Field(..., min_length=1)
    status: str = "Active"
    capacity_percent: int = Field(0, ge=0, le=100)
    operating_hours: str = "24/7"
    tags: List[str] = Field(default_factory=list)
    description: str = ""

class ResourceUpdate(BaseModel):
    status: Optional[str] = None
    capacity_percent: Optional[int] = Field(None, ge=0, le=100)

@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    page = ROOT / "web" / "index.html"
    if not page.exists():
        raise HTTPException(404, "Frontend file web/index.html was not found.")
    return page.read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "message": "Local Resource Directory server is running"}

@app.get("/api/meta")
def get_metadata():
    return {"categories": sorted(VALID_CATEGORIES), "statuses": sorted(VALID_STATUSES), "warnings": engine.load_warnings}

@app.get("/api/resources")
def list_resources(q: str = Query(""), category: Optional[str] = None, status: Optional[str] = None,
                   max_capacity: Optional[int] = Query(None, ge=0, le=100), open_only: bool = False):
    return [r.to_dict() for r in engine.search(q, category, status, max_capacity, open_only)]

@app.get("/api/resources/{resource_id}")
def get_single_resource(resource_id: str):
    res = engine.get_resource(resource_id)
    if not res:
        raise HTTPException(404, f"Resource '{resource_id}' not found.")
    return res.to_dict()

@app.post("/api/resources", status_code=201)
def create_resource(payload: ResourceCreate):
    try:
        item = Resource(**payload.model_dump())
        return engine.add_resource(item).to_dict()
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.patch("/api/resources/{resource_id}")
def update_resource(resource_id: str, payload: ResourceUpdate):
    current = engine.get_resource(resource_id)
    if not current:
        raise HTTPException(404, f"Resource '{resource_id}' not found.")
    try:
        return engine.update_status(resource_id,
            payload.status if payload.status is not None else current.status,
            payload.capacity_percent if payload.capacity_percent is not None else current.capacity_percent).to_dict()
    except (ValueError, KeyError) as exc:
        raise HTTPException(400, str(exc))

@app.delete("/api/resources/{resource_id}")
def delete_resource(resource_id: str):
    if not engine.delete_resource(resource_id):
        raise HTTPException(404, f"Resource '{resource_id}' not found.")
    return {"deleted": True, "id": resource_id}

@app.get("/api/summary")
def get_summary():
    data = engine.generate_summary()
    for key in ("critical_alerts", "high_availability"):
        data[key] = [r.to_dict() for r in data[key]]
    return data

@app.get("/api/audit")
def get_audit_findings():
    return [{"severity": f.severity, "resource_id": f.resource_id, "resource_name": f.resource_name,
             "issue": f.issue, "recommendation": f.recommendation}
            for f in auditor.audit(engine.resources, stale_hours=24)]

@app.get("/api/export/csv")
def export_csv():
    path = exporter.to_csv(engine.resources)
    return FileResponse(path, media_type="text/csv", filename="local_community_resources.csv")

@app.get("/api/export/markdown")
def export_markdown():
    path = exporter.summary_to_markdown(engine.generate_summary())
    return FileResponse(path, media_type="text/markdown", filename="daily_briefing.md")
