import argparse
from server import start_server

def main():
    parser = argparse.ArgumentParser(description="Local Resource Directory")
    parser.add_argument("--web", "--server", action="store_true", help="Start the web dashboard")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if args.web:
        start_server(args.host, args.port)
    else:
        print("Start the web dashboard with: py main.py --web")

if __name__ == "__main__":
    main()
