import uvicorn

def start_server(host="127.0.0.1", port=8000):
    uvicorn.run("app:app", host=host, port=port, reload=False)

if __name__ == "__main__":
    start_server()
