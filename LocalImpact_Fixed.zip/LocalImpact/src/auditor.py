from datetime import datetime, timezone, timedelta

class Finding:
    def __init__(self, severity, resource, issue, recommendation):
        self.severity = severity
        self.resource_id = resource.id
        self.resource_name = resource.name
        self.issue = issue
        self.recommendation = recommendation

class DirectoryAuditor:
    def audit(self, resources, stale_hours=24):
        findings = []
        cutoff = datetime.now(timezone.utc) - timedelta(hours=stale_hours)
        for r in resources:
            if r.capacity_percent >= 85:
                findings.append(Finding("HIGH", r, f"Capacity is {r.capacity_percent}%.", "Confirm remaining capacity and consider redirecting new arrivals."))
            try:
                updated = datetime.fromisoformat(r.updated_at.replace("Z", "+00:00"))
                if updated.tzinfo is None:
                    updated = updated.replace(tzinfo=timezone.utc)
                if updated < cutoff:
                    findings.append(Finding("MEDIUM", r, "Record has not been updated recently.", "Verify contact details, hours, status, and capacity."))
            except (ValueError, AttributeError):
                findings.append(Finding("MEDIUM", r, "Update timestamp is missing or invalid.", "Refresh this resource record."))
        return findings
