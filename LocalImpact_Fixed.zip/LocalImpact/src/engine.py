from datetime import datetime, time
from .models import Resource, VALID_STATUSES

class DirectoryEngine:
    def __init__(self, storage):
        self.storage = storage
        self.resources = storage.load()
        self.load_warnings = storage.load_warnings

    def _save(self):
        self.storage.save([r.to_dict() for r in self.resources])

    def search(self, query="", category=None, status=None, max_capacity=None, is_open_only=False):
        q = (query or "").lower().strip()
        results = self.resources
        if q:
            results = [r for r in results if q in " ".join([r.name, r.address, r.description, r.category, " ".join(r.tags)]).lower()]
        if category:
            results = [r for r in results if r.category == category]
        if status:
            results = [r for r in results if r.status == status]
        if max_capacity is not None:
            results = [r for r in results if r.capacity_percent <= max_capacity]
        if is_open_only:
            results = [r for r in results if r.status == "Active"]
        return list(results)

    def get_resource(self, resource_id):
        return next((r for r in self.resources if r.id == resource_id), None)

    def add_resource(self, resource):
        if any(r.name.lower() == resource.name.lower() and r.address.lower() == resource.address.lower() for r in self.resources):
            raise ValueError("A resource with this name and address already exists.")
        self.resources.append(resource)
        self._save()
        return resource

    def update_status(self, resource_id, new_status, new_capacity):
        if new_status not in VALID_STATUSES:
            raise ValueError("Invalid status.")
        if not 0 <= int(new_capacity) <= 100:
            raise ValueError("Capacity must be between 0 and 100.")
        resource = self.get_resource(resource_id)
        if not resource:
            raise KeyError(resource_id)
        resource.status = new_status
        resource.capacity_percent = int(new_capacity)
        resource.updated_at = datetime.now().astimezone().isoformat()
        self._save()
        return resource

    def delete_resource(self, resource_id):
        resource = self.get_resource(resource_id)
        if not resource:
            return False
        self.resources.remove(resource)
        self._save()
        return True

    def generate_summary(self):
        total = len(self.resources)
        avg = round(sum(r.capacity_percent for r in self.resources) / total, 1) if total else 0
        return {
            "total_resources": total,
            "active_resources": sum(r.status == "Active" for r in self.resources),
            "closed_resources": sum(r.status == "Closed" for r in self.resources),
            "average_capacity": avg,
            "critical_alerts": [r for r in self.resources if r.capacity_percent >= 85 or r.status in {"Full", "Closed"}],
            "high_availability": [r for r in self.resources if r.status == "Active" and r.capacity_percent <= 30],
        }
