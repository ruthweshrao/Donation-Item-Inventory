import csv
from pathlib import Path

class DirectoryExporter:
    def __init__(self, output_dir="exports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def to_csv(self, resources, filename="resources_directory.csv"):
        path = self.output_dir / filename
        rows = [r.to_dict() for r in resources]
        fields = list(rows[0].keys()) if rows else ["id", "name", "category", "address", "contact", "status", "capacity_percent", "operating_hours", "tags", "description", "updated_at"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                row = row.copy()
                row["tags"] = ", ".join(row.get("tags", []))
                writer.writerow(row)
        return path

    def summary_to_markdown(self, summary, filename="daily_briefing.md"):
        path = self.output_dir / filename
        lines = ["# Local Resource Directory — Daily Briefing", "", f"- Total resources: {summary['total_resources']}", f"- Active resources: {summary['active_resources']}", f"- Average capacity: {summary['average_capacity']}%", "", "## Critical alerts"]
        for r in summary["critical_alerts"]:
            lines.append(f"- **{r.name}** — {r.status}, {r.capacity_percent}% capacity")
        path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")
        return path
