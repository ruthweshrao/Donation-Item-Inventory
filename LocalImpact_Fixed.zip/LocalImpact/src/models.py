from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from uuid import uuid4

VALID_CATEGORIES = {
    "Healthcare", "Shelter", "Food Bank", "Education",
    "Emergency", "Community Support", "Other"
}
VALID_STATUSES = {"Active", "Limited", "Full", "Closed"}

@dataclass
class Resource:
    name: str
    category: str
    address: str
    contact: str
    status: str = "Active"
    capacity_percent: int = 0
    operating_hours: str = "24/7"
    tags: list[str] = field(default_factory=list)
    description: str = ""
    id: str = field(default_factory=lambda: str(uuid4())[:8])
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def __post_init__(self):
        self.name = self.name.strip()
        self.category = self.category.strip()
        self.address = self.address.strip()
        self.contact = self.contact.strip()
        if not self.name or not self.address or not self.contact:
            raise ValueError("Name, address, and contact are required.")
        if self.category not in VALID_CATEGORIES:
            raise ValueError(f"Invalid category. Choose one of: {', '.join(sorted(VALID_CATEGORIES))}")
        if self.status not in VALID_STATUSES:
            raise ValueError(f"Invalid status. Choose one of: {', '.join(sorted(VALID_STATUSES))}")
        if not 0 <= int(self.capacity_percent) <= 100:
            raise ValueError("Capacity must be between 0 and 100.")
        self.capacity_percent = int(self.capacity_percent)
        self.tags = [str(t).strip() for t in self.tags if str(t).strip()]

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        allowed = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in value.items() if k in allowed})
