import json
import os
from pathlib import Path
from .models import Resource

class DirectoryStorage:
    def __init__(self, path="data/directory.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.load_warnings = []
        if not self.path.exists():
            self.save(self.seed_data())

    def seed_data(self):
        examples = [
            dict(name="City General Clinic", category="Healthcare", address="Main Road", contact="040-1000001", status="Active", capacity_percent=62, operating_hours="24/7", tags=["clinic", "medical"], description="Primary healthcare support."),
            dict(name="Community Shelter", category="Shelter", address="Station Road", contact="040-1000002", status="Active", capacity_percent=88, operating_hours="24/7", tags=["shelter", "housing"], description="Temporary accommodation."),
            dict(name="Hope Food Bank", category="Food Bank", address="Market Street", contact="040-1000003", status="Active", capacity_percent=35, operating_hours="09:00-18:00", tags=["food", "meals"], description="Food assistance for families."),
        ]
        return [Resource(**x).to_dict() for x in examples]

    def load(self):
        self.load_warnings = []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("Directory JSON must contain a list.")
        except (json.JSONDecodeError, OSError, ValueError) as exc:
            self.load_warnings.append(f"Could not read directory data: {exc}")
            return []
        resources = []
        for index, item in enumerate(raw):
            try:
                resources.append(Resource.from_dict(item))
            except Exception as exc:
                self.load_warnings.append(f"Skipped invalid record {index + 1}: {exc}")
        return resources

    def save(self, resources):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        if self.path.exists():
            try:
                temp.with_suffix(temp.suffix + ".bak").write_bytes(self.path.read_bytes())
            except OSError:
                pass
        temp.write_text(json.dumps(resources, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, self.path)
